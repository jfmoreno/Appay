function Entidad() {}

Entidad.prototype.beginDraw = function(){
};
Entidad.prototype.beginDrawImprime = function(){
};

Entidad.prototype.endDraw = function(){
};

Entidad.prototype.endDrawImprime = function(){
};